import sys,time,json
from pathlib import Path
from lo_run import *
V=Path('/data/v83');sys.stdout.reconfigure(line_buffering=True)
extra='''
Function Focus(ByVal scenario As String) As String
    Dim sh As Worksheet, n As Long, r As Long, before As Long, v As Variant
    Dim code As String, d As String, old As Variant, reason As String, q As Double, ok As Boolean
    gSilent = True
    code = Txt(WS(SH_NOM).Cells(FIRST_ROW, 1).Value)
    before = LastRow(WS(SH_MOVE), J_OP)
    Select Case scenario
    Case "compile"
        Focus = Install_Check(): Exit Function
    Case "selftest_guard"
        d = RunSelfTest("")
        ok = InStr(d, "ОТКАЗ") > 0 And LastRow(WS(SH_MOVE), J_OP) = before
    Case "references"
        d = ReferenceErrors()
        ok = Len(d) = 0 And InStr(MissingBundleBOMs(), "ПТ-00017877/76") > 0 And InStr(MissingBundleBOMs(), "ПТ-00017879/78") > 0
    Case "bad_norm"
        Set sh = WS(SH_SPEC): old = sh.Cells(FIRST_ROW, 4).Value
        sh.Cells(FIRST_ROW, 4).Value = 0
        d = AssembleCore(Txt(sh.Cells(FIRST_ROW, 1).Value), 1, Txt(WS(SH_ORDERS).Cells(FIRST_ROW, 1).Value), Date)
        ok = Len(d) = 0 And LastRow(WS(SH_MOVE), J_OP) = before
        sh.Cells(FIRST_ROW, 4).Value = old
    Case "bad_pfd"
        Set sh = WS(SH_PFD): old = sh.Cells(FIRST_ROW, 6).Value
        sh.Cells(FIRST_ROW, 6).Value = 99999
        d = AssembleCore(Txt(sh.Cells(FIRST_ROW, 1).Value), 1, Txt(WS(SH_ORDERS).Cells(FIRST_ROW, 1).Value), Date)
        ok = Len(d) = 0 And Len(ReferenceErrors()) > 0 And LastRow(WS(SH_MOVE), J_OP) = before
        sh.Cells(FIRST_ROW, 6).Value = old
    Case "duplicate_order"
        Set sh = WS(SH_ORDERS): n = LastRow(sh, 1) + 1
        sh.Range(sh.Cells(FIRST_ROW, 1), sh.Cells(FIRST_ROW, 5)).Copy sh.Cells(n, 1)
        ok = InStr(ReferenceErrors(), "Дублируется заказ") > 0
        sh.Rows(n).Delete
    Case "rollback"
        Set sh = WS(SH_OPS): r = FindRow(sh, 1, "09")
        old = sh.Cells(r, 9).Value: sh.Cells(r, 9).Value = "Нет"
        d = AssembleCore(Txt(WS(SH_SPEC).Cells(FIRST_ROW, 1).Value), 1, Txt(WS(SH_ORDERS).Cells(FIRST_ROW, 1).Value), Date)
        ok = Len(d) = 0 And LastRow(WS(SH_MOVE), J_OP) = before
        sh.Cells(r, 9).Value = old
    Case "protected_delete"
        ok = Not NomDeleteCore(Txt(WS(SH_PFD).Cells(FIRST_ROW, 1).Value), False)
        ok = ok And NomRow(Txt(WS(SH_PFD).Cells(FIRST_ROW, 1).Value)) > 0
    Case "nom_lifecycle"
        Set sh = WS(SH_NOM): n = LastRow(sh, 1) + 1
        sh.Cells(n, 1).Value = "TEST-LIFECYCLE"
        sh.Cells(n, 2).Value = "Удаляемая тестовая позиция"
        sh.Cells(n, 3).Value = T_PART: sh.Cells(n, 4).Value = "шт": sh.Cells(n, 10).Value = "Да"
        ok = NomDeleteCore("TEST-LIFECYCLE", False) And NomRow("TEST-LIFECYCLE") = 0
        r = FindRow(WS(SH_TRASH), 1, "TEST-LIFECYCLE")
        ok = ok And NomRestoreCore(r)
        r = NomRow("TEST-LIFECYCLE"): ok = ok And r > 0
        If r > 0 Then sh.Rows(r).Delete
    Case "row_lifecycle"
        Set sh = WS(SH_INPUT): n = InputLastRow()
        InsertRowsCore sh, IN_FIRST + 1, 2
        ok = sh.Cells(IN_FIRST + 1, L_NAME).HasFormula
        DeleteRowsCore sh, IN_FIRST + 1, IN_FIRST + 2, False
        ok = ok And sh.Cells(IN_FIRST, L_NAME).HasFormula
    Case "move_restore"
        Set sh = WS(SH_MOVE): r = LastRow(sh, J_OP)
        d = Txt(sh.Cells(r, J_DOC).Value): q = Nz(sh.Cells(r, J_QTY).Value)
        ok = DeleteRowsCore(sh, r, r, False)
        n = LastRow(WS(SH_DELMOVE), J_OP)
        ok = ok And MoveRestoreCore(n)
        ok = ok And LastRow(sh, J_OP) = before And Txt(sh.Cells(before, J_DOC).Value) = d And Nz(sh.Cells(before, J_QTY).Value) = q And sh.Cells(before, J_FROM).HasFormula
    Case "fill_spec"
        Set sh = WS(SH_INPUT)
        sh.Range(IN_ITEM).Value = Txt(WS(SH_SPEC).Cells(FIRST_ROW, 1).Value)
        sh.Range(IN_KQTY).Value = 1
        Input_FillBySpec
        ok = Len(Txt(sh.Cells(IN_FIRST, L_CODE).Value)) > 0 And Not IsVarParent(Txt(sh.Cells(IN_FIRST, L_CODE).Value))
        n = InputLastRow()
        sh.Range(sh.Cells(IN_FIRST, L_CODE), sh.Cells(n, L_CODE)).ClearContents
        sh.Range(sh.Cells(IN_FIRST, L_QTY), sh.Cells(n, L_ATO)).ClearContents
    Case "reports"
        Reports_RefreshAll
        d = ReferenceErrors(): ok = ControlErrors() = 0 And Len(d) = 0
    End Select
    Focus = IIf(ok, "PASS|", "FAIL|") & scenario & "|" & d & "|" & gLastError
End Function
Function FilesFocus(ByVal folder As String) As String
    Dim f As String, d As String, n As Long, code As String, sh As Worksheet
    gSilent = True: code = Txt(WS(SH_NOM).Cells(FIRST_ROW, 1).Value)
    f = AttachFileCore(folder & "/invoice_001.pdf", "Накладная с произвольным названием")
    f = AttachFileCore(folder & "/pallet_photo.jpg", "Фотография приёмки")
    If PendingFilesCount() <> 2 Then FilesFocus = "FAIL|pending": Exit Function
    Set sh = WS(SH_INPUT)
    sh.Range(IN_DATE).Value = DateSerial(2026, 10, 2): sh.Range(IN_OP).Value = OpFullName("01")
    sh.Cells(IN_FIRST, L_CODE).Value = code: sh.Cells(IN_FIRST, L_QTY).Value = 1
    n = LastRow(WS(SH_MOVE), J_OP)
    Post_FromInput
    If LastRow(WS(SH_MOVE), J_OP) <> n + 1 Or PendingFilesCount() <> 0 Then FilesFocus = "FAIL|input " & gLastError: Exit Function
    d = Txt(WS(SH_MOVE).Cells(n + 1, J_DOC).Value)
    f = AttachFileCore(folder & "/defect_act.docx", "Акт без привязки к шаблону имени", d)
    If Len(f) = 0 Or Len(MissingFiles()) > 0 Then FilesFocus = "FAIL|archive": Exit Function
    ShowImage FullFilePath(Txt(WS(SH_FILES).Cells(FIRST_ROW + 1, F_PATH).Value)), "Проверка фото"
    FilesFocus = "PASS|" & d & "|files=3|shapes=" & WS(SH_PREVIEW).Shapes.Count
End Function
Function PubFocus() As String
    gSilent = True
    Publish_Data
    PubFocus = gLastPublished & "|" & gLastError
End Function
'''
p,desk=start();res=[]
try:
 doc=desk.loadComponentFromURL(uno.systemPathToFileUrl(str(V/'testdata/Focus_Input.xlsx')),'_blank',0,(pv('Hidden',False),pv('MacroExecutionMode',4)))
 load_modules(doc,str(V/'src/VBA_Operator'),extra)
 for s in ['compile','selftest_guard','references','bad_norm','bad_pfd','duplicate_order','rollback','protected_delete','nom_lifecycle','row_lifecycle','move_restore','fill_spec','reports']:
  t=time.time();val=call(doc,'LOHarness','Focus',(s,));print(s,str(val)[:500],round(time.time()-t,2),flush=True);res.append([s,str(val)])
  if s!='compile' and not str(val).startswith('PASS|'):raise RuntimeError((s,val))
 val=call(doc,'LOHarness','FilesFocus',(str(V/'testdata/Samples'),));print(val,flush=True);res.append(['files',str(val)])
 if not str(val).startswith('PASS|'):raise RuntimeError(val)
 doc.storeToURL(uno.systemPathToFileUrl(str(V/'out/Native_PrePublish.xlsx')),(pv('FilterName','Calc MS Excel 2007 XML'),))
 val=call(doc,'LOHarness','PubFocus');print('publish',val,flush=True);res.append(['publish',str(val)])
 if 'ELKA_data_' not in str(val):raise RuntimeError(val)
 doc.storeToURL(uno.systemPathToFileUrl(str(V/'out/Native_Final.xlsx')),(pv('FilterName','Calc MS Excel 2007 XML'),));doc.close(True)
 (V/'tests_out/focused_results.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
finally:
 try:desk.terminate()
 except:pass
 time.sleep(1);p.kill()
