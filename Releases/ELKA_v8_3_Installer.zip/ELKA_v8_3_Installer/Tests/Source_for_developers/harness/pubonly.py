import time,sys
from lo_run import *
p,desk=start()
try:
 doc=desk.loadComponentFromURL(uno.systemPathToFileUrl('/data/v83/testdata/Pub_Input.xlsx'),'_blank',0,(pv('Hidden',False),pv('MacroExecutionMode',4)))
 load_modules(doc,'/data/v83/src/VBA_Operator','''Function TPub() As String
 gSilent = True
 Publish_Data
 TPub = gLastPublished & "|" & gLastError
End Function''')
 t=time.time();print(call(doc,'LOHarness','TPub'),round(time.time()-t,2),flush=True);doc.close(True)
finally:
 try:desk.terminate()
 except:pass
 time.sleep(1);p.kill()
