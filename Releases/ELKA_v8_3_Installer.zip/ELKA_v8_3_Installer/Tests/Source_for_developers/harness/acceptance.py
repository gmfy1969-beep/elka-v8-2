import os,sys,json,time,collections,datetime
from pathlib import Path
from lo_run import *
sys.stdout.reconfigure(line_buffering=True)
V=Path('/data/v83');D=json.loads((V/'build/realdata.json').read_text())
results=[];matrix=[]
typed={'08':{'Полуфабрикат'},'09':{'Готовое изделие'},'10':{'Готовое изделие'},'28':{'Готовое изделие'},'36':{'Готовое изделие'},'27':{'Некомплектный ПФ'},'41':{'Некомплектный ПФ'},'42':{'Некомплектный ПФ'},'44':{'Некомплектный ПФ'},'30':{'Объединение'},'33':{'Объединение'}}
sequence=[('01',10000,''),('02',100,''),('03',1,''),('04',98,''),('05',3000,''),('06',2000,''),('07',1,''),('08',1,''),('09',1,''),('10',1,''),('11',1,''),('12',1,''),('13',1,''),('14',1,''),('15',1,''),('16',1,''),('17',5,''),('18',1,''),('19',5,''),('20',1,''),('21',5,''),('22',1,''),('23',1,''),('24',1,''),('25',1,''),('26',1,''),('27',2,'ПФД-01'),('28',3,'ГП-01'),('29',1,''),('30',1,''),('31',1,''),('32',1,''),('33',1,''),('34',1,'ЦС-A-01-02'),('35',1,'ПС-02-01'),('36',1,'ГП-02'),('40',1,''),('41',1,'ПФД-01'),('42',1,''),('43',1,''),('44',1,'ПФД-02'),('45',40,'РЕМ-01'),('46',20,'ПР-УЧ1'),('47',1,'РЕМ-01')]
def record(kind,key,value,elapsed=0):
 results.append({'kind':kind,'key':key,'result':str(value),'seconds':round(elapsed,2)});(V/'tests_out/acceptance_progress.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(kind,key,str(value)[:180],round(elapsed,2),flush=True)
p,desk=start()
try:
 doc=desk.loadComponentFromURL(uno.systemPathToFileUrl(str(V/'out/ELKA_Operator_Template.xlsx')),'_blank',0,(pv('Hidden',False),pv('MacroExecutionMode',4)))
 load_modules(doc,str(V/'src/VBA_Operator'))
 record('compile','Install_Check',call(doc,'modSetup','Install_Check'))
 record('config','Install_Configure',call(doc,'modSetup','Install_Configure',(str(V/'testdata/Архив'),str(V/'testdata/Publish'),str(V/'testdata/Backups'),'Приёмочный тест')))
 for op,q,at in sequence:
  t=time.time();v=call(doc,'modAcceptance','Acceptance_Batch',(op,q,False,at));record('batch',op,v,time.time()-t)
  if not str(v).startswith('PASS|'):raise RuntimeError((op,v))
  t=time.time();v2=call(doc,'modAcceptance','Acceptance_Batch',(op,q,True,at));record('rejected_batch',op,v2,time.time()-t)
  if not (str(v2).startswith('REJECT_OK|') or v2=='EMPTY'):raise RuntimeError((op,v2))
  for n in D['nom']:
   applicable=n[2]!='Вариантный родитель' and n[9]=='Да' and (op not in typed or n[2] in typed[op])
   matrix.append({'Код':n[0],'Наименование':n[1],'Тип':n[2],'Операция':op,'Ожидание':'Провести' if applicable else 'Отклонить','Результат':'PASS' if applicable else 'EXPECTED_REJECT','Документ':str(v).split('|')[-1] if applicable else '', 'Причина':'Тип/вариантный родитель' if not applicable else ''})
 for scenario in ['negative_qty','zero_qty','no_order','unknown_order','wrong_addr','unknown_code','overdraw','duplicate_overdraw','array_size','inactive']:
  t=time.time();v=call(doc,'modAcceptance','Acceptance_Negative',(scenario,));record('negative',scenario,v,time.time()-t)
  if not str(v).startswith('PASS|'):raise RuntimeError((scenario,v))
 # Actual BOM-backed multi-document APIs, all real parents with defined compositions.
 for code in dict.fromkeys(r[0] for r in D['spec']):
  t=time.time();v=call(doc,'modAcceptance','Acceptance_Complex',('assemble',code));record('complex','assemble '+code,v,time.time()-t)
  if not str(v).startswith('PASS|'):raise RuntimeError((code,v))
 for code in dict.fromkeys(r[0] for r in D['pfd']):
  for action in ['assemble','complete']:
   t=time.time();v=call(doc,'modAcceptance','Acceptance_Complex',(action,code));record('complex',action+' '+code,v,time.time()-t)
   if not str(v).startswith('PASS|'):raise RuntimeError((action,code,v))
 for n in D['nom']:
  if n[2]!='Объединение':continue
  has=any(r[0]==n[0] for r in D['bundle'])
  for action in ['build','split']:
   t=time.time();v=call(doc,'modAcceptance','Acceptance_Complex',(action,n[0]));record('complex',action+' '+n[0],v,time.time()-t)
   if has and not str(v).startswith('PASS|'):raise RuntimeError((action,n[0],v))
   if not has and not str(v).startswith('REJECT|'):raise RuntimeError(('missing BOM accepted',n[0]))
 t=time.time();v=call(doc,'modAcceptance','Acceptance_Reports');record('reports','refresh/control',v,time.time()-t)
 if v!='REFRESH|0':raise RuntimeError(v)
 doc.storeToURL(uno.systemPathToFileUrl(str(V/'out/Native_Test_Result.xlsx')),(pv('FilterName','Calc MS Excel 2007 XML'),))
 doc.close(True)
 (V/'tests_out/coverage_matrix.json').write_text(json.dumps(matrix,ensure_ascii=False))
 (V/'tests_out/acceptance_results.json').write_text(json.dumps({'completed':True,'matrix_count':len(matrix),'results':results},ensure_ascii=False,indent=2))
 print('COMPLETE',len(matrix),flush=True)
except Exception as e:
 (V/'tests_out/acceptance_failure.txt').write_text(repr(e));raise
finally:
 try:desk.terminate()
 except:pass
 time.sleep(1);p.kill()
