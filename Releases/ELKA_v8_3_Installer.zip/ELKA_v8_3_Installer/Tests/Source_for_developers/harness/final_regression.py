import time,sys,json
from lo_run import *
extra='''
Function FinalChecks() As String
    Dim before As Long, s As String, d As String, a As String, b As String, r As Long
    gSilent = True
    before = LastRow(WS(SH_MOVE), J_OP)
    ELKA_SelfTest
    If InStr(WS("Тест_отчёт").Cells(3, 1).Value, "ОТКАЗ") = 0 Then FinalChecks = "FAIL test-report": Exit Function
    If LastRow(WS(SH_MOVE), J_OP) <> before Then FinalChecks = "FAIL guard": Exit Function
    a = Txt(WS(SH_PFD).Cells(FIRST_ROW, 1).Value)
    For r = FIRST_ROW + 1 To LastRow(WS(SH_PFD), 1)
        b = Txt(WS(SH_PFD).Cells(r, 1).Value)
        If PFDTarget(b) <> PFDTarget(a) Then Exit For
    Next r
    d = PFDCompleteCore(a, 1, Txt(WS(SH_ORDERS).Cells(FIRST_ROW, 1).Value), Date, b)
    If Len(d) > 0 Or LastRow(WS(SH_MOVE), J_OP) <> before Then FinalChecks = "FAIL reclass-target": Exit Function
    d = PFDCompleteCore(a, 1, Txt(WS(SH_ORDERS).Cells(FIRST_ROW, 1).Value), Date, a)
    If Len(d) > 0 Or LastRow(WS(SH_MOVE), J_OP) <> before Then FinalChecks = "FAIL reclass-same": Exit Function
    FinalChecks = "PASS|selftest guard and report sheet creation|incompatible reclass target|same-code reclass|no journal changes"
End Function
'''
p,desk=start()
try:
 d=desk.loadComponentFromURL(uno.systemPathToFileUrl('/data/v83/testdata/Final_Regression_Input.xlsx'),'_blank',0,(pv('Hidden',False),pv('MacroExecutionMode',4)))
 load_modules(d,'/data/v83/src/VBA_Operator',extra);v=call(d,'LOHarness','FinalChecks');print(v,flush=True)
 if not str(v).startswith('PASS|'):raise RuntimeError(v)
 d.close(True)
finally:
 try:desk.terminate()
 except:pass
 time.sleep(1);p.kill()
