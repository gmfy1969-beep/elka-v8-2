# Preserve the final builder's structure. Reuse only matching formulas' verified caches.
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import xml.etree.ElementTree as E,copy,json
V=Path('/data/v83');ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'};S='{'+ns['s']+'}'
def mapping(z):
 rel=E.fromstring(z.read('xl/_rels/workbook.xml.rels'));rr={r.attrib['Id']:r.attrib['Target'] for r in rel}
 book=E.fromstring(z.read('xl/workbook.xml'));out={}
 for sh in book.find(S+'sheets'):
  target=rr[sh.attrib['{'+ns['r']+'}id']];out[sh.attrib['name']]=target.lstrip('/') if target.startswith('/') else 'xl/'+target
 return out
src=ZipFile(V/'out/Native_Final.xlsx');sm=mapping(src);target=V/'out/ELKA_Operator_Demo.xlsx';tmp=target.with_suffix('.tmp');count=0;skipped=0
with ZipFile(target) as z,ZipFile(tmp,'w',ZIP_DEFLATED) as out:
 tm=mapping(z);lookup={v:k for k,v in tm.items()}
 for info in z.infolist():
  data=z.read(info.filename);name=lookup.get(info.filename)
  if name in sm:
   root=E.fromstring(data);sr=E.fromstring(src.read(sm[name]));sc={c.attrib['r']:c for c in sr.iter(S+'c') if c.find(S+'f') is not None}
   for c in root.iter(S+'c'):
    f=c.find(S+'f');old=sc.get(c.attrib['r'])
    if f is None:continue
    if old is None or old.find(S+'f').text!=f.text:skipped+=1;continue
    v=old.find(S+'v')
    if v is None:skipped+=1;continue
    oldv=c.find(S+'v')
    if oldv is not None:c.remove(oldv)
    c.append(copy.deepcopy(v))
    if 't' in old.attrib:c.attrib['t']=old.attrib['t']
    else:c.attrib.pop('t',None)
    count+=1
   data=E.tostring(root,encoding='utf-8',xml_declaration=True)
  out.writestr(info,data)
tmp.replace(target);src.close();result={'matching_formula_caches_copied':count,'unmatched_left_to_Excel_recalc':skipped,'source':'Native_Final.xlsx','target':target.name};(V/'tests_out/cache_transfer.json').write_text(json.dumps(result,indent=2));print(result)
