from pathlib import Path
import openpyxl,json,collections,csv,sys,hashlib,math
V=Path('/data/v83');path=Path(sys.argv[1]) if len(sys.argv)>1 else V/'out/Native_Test_Result.xlsx'
D=json.loads((V/'build/realdata.json').read_text());M=json.loads((V/'tests_out/coverage_matrix.json').read_text())
w=openpyxl.load_workbook(path,data_only=True);wf=openpyxl.load_workbook(path,data_only=False)
nom={n[0]:n for n in D['nom']};ops={r[0]+' '+r[1]:r for r in D['ops']};locs=[r[0] for r in D['loc'] if r[3]=='Да'];addr={r[0]:r[1] for r in D['addr']};bal=collections.defaultdict(float);ab=collections.defaultdict(float);errs=[];seen=collections.Counter();count=0;chron=[]
for i,r in enumerate(w['Движение'].iter_rows(min_row=4,values_only=True),4):
 if not r[2]:continue
 count+=1;op=ops.get(r[2]);code=r[3];q=r[5]
 if not op or code not in nom or nom[code][2]=='Вариантный родитель' or not isinstance(q,(int,float)) or q<=0:errs.append(['bad_row',i]);continue
 seen[code,op[0]]+=1
 if tuple(r[7:9])!=tuple(op[2:4]):errs.append(['route',i,r[7:9],op[2:4]])
 if r[18]!='OK':errs.append(['journal_check',i,r[18]])
 for place,a,delta in [(op[2],r[9],-q),(op[3],r[10],q)]:
  if place not in locs:continue
  a = a or ""
  bal[code,place]+=delta;ab[code,place,a]+=delta
  if a and addr.get(a)!=place:errs.append(['address',i,place,a])
  if bal[code,place]<-1e-7 or ab[code,place,a]<-1e-7:chron.append([i,code,place,a,bal[code,place],ab[code,place,a]])
checks=0;stock={r[0]:r for r in w['Остатки'].iter_rows(min_row=4,values_only=True) if r[0]}
for code in nom:
 r=stock.get(code)
 if r is None:errs.append(['missing_stock_row',code]);continue
 for j,loc in enumerate(locs,4):
  checks+=1
  if abs((r[j] or 0)-bal[code,loc])>1e-7:errs.append(['stock_formula',code,loc,r[j],bal[code,loc]])
 if abs((r[16] or 0)-sum(bal[code,l] for l in locs))>1e-7:errs.append(['total',code])
 for j in range(5,13):
  if not str(wf['Остатки'].cell(list(stock).index(code)+4,j).value).startswith('='):errs.append(['missing_formula',code,j])
reported={(r[0],r[2],('' if r[3]=='(без адреса)' else (r[3] or ''))):r[4] for r in w['Остатки_адреса'].iter_rows(min_row=4,values_only=True) if r[0]}
for key,q in ab.items():
 if abs(q)>1e-7 and abs(reported.get(key,0)-q)>1e-7:errs.append(['address_report',key,q,reported.get(key)])
for row in M:
 if row['Результат']=='PASS' and seen[row['Код'],row['Операция']]==0:errs.append(['matrix_missing',row['Код'],row['Операция']])
 if row['Результат']=='EXPECTED_REJECT' and seen[row['Код'],row['Операция']]>0:errs.append(['matrix_bad_accept',row['Код'],row['Операция']])
for sh in w:
 for row in sh.iter_rows():
  for c in row:
   if c.data_type=='e':errs.append(['excel_error',sh.title,c.coordinate,c.value])
# all exact original names retained; types intentionally normalized
src=openpyxl.load_workbook(V/'source/Original_ELKA_v6_1.xlsm',data_only=True)
sn={str(r[0]).strip():str(r[1]).strip() for r in src['Справочник'].iter_rows(min_row=4,values_only=True) if r[0]}
if len(sn)!=255 or set(sn)!=set(nom):errs.append(['source_codes'])
for c,n in nom.items():
 if sn.get(c)!=n[1]:errs.append(['source_name',c,sn.get(c),n[1]])
report={'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'journal_rows':count,'matrix_rows':len(M),'matrix_pass':sum(r['Результат']=='PASS' for r in M),'matrix_expected_reject':sum(r['Результат']=='EXPECTED_REJECT' for r in M),'codes':len(nom),'operations':len(D['ops']),'stock_formula_comparisons':checks,'address_nonzero_rows':len(reported),'chronological_negative_count':len(chron),'errors':errs,'chronological_examples':chron[:4],'status':'PASS' if not errs and not chron else 'FAIL'}
(V/'tests_out/independent_ledger.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
with (V/'tests_out/Matrix_255x44.csv').open('w',encoding='utf-8-sig',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(M[0]),delimiter=';');wr.writeheader();wr.writerows(M)
assert report['status']=='PASS'
