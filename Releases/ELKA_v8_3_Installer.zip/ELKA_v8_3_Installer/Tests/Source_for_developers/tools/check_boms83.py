import json,openpyxl,collections
from pathlib import Path
V=Path('/data/v83');D=json.loads((V/'build/realdata.json').read_text());R=json.loads((V/'tests_out/acceptance_results.json').read_text());W=openpyxl.load_workbook(V/'out/Native_Test_Result.xlsx',data_only=True)
nom={r[0]:r for r in D['nom']};docs=collections.defaultdict(list)
for r in W['Движение'].iter_rows(min_row=4,values_only=True):
 if r[2]:docs[r[14]].append(r)
def norm(rows,parent):
 a=collections.defaultdict(float)
 for x in rows:
  if x[0]==parent:a[x[1]]+=float(x[2])
 return dict(a)
def comp(rows,expected):
 a=collections.defaultdict(float)
 for r in rows:
  code=r[3];base=nom[code][5];a[base if base in expected else code]+=r[5]
 return dict(a)
def match(actual,expected):return set(actual)==set(expected) and all(abs(actual[k]-expected[k])<1e-7 for k in actual)
errs=[];n=0
for rec in R['results']:
 if rec['kind']!='complex' or not rec['result'].startswith('PASS|'):continue
 action,code=rec['key'].split(' ',1);ids=rec['result'][5:].split('+');expected={};target=code
 if action=='assemble':
  target=code
  if nom[code][2]=='Некомплектный ПФ':
   full=next(r[1] for r in D['pfd'] if r[0]==code);expected=norm(D['spec'],full)
   for r in D['pfd']:
    if r[0]==code:expected[r[2]]-=r[3]
   expected={c:q for c,q in expected.items() if q>1e-7}
  else:expected=norm(D['spec'],code)
  actual=comp(docs[ids[0]],expected)
 elif action=='complete':
  for r in D['pfd']:
   if r[0]==code:expected[r[2]]=expected.get(r[2],0)+r[3];target=r[1]
  actual=comp(docs[ids[1]],expected)
 elif action in ['build','split']:
  expected=norm(D['bundle'],code);actual=comp(docs[ids[0] if action=='build' else ids[-1]],expected)
 if not match(actual,expected):errs.append([rec['key'],'BOM',actual,expected])
 if action!='split':
  out=docs[ids[-1]]
  if len(out)!=1 or out[0][3]!=target or out[0][5]!=1:errs.append([rec['key'],'output'])
 else:
  out=docs[ids[0]]
  if len(out)!=1 or out[0][3]!=code or out[0][5]!=1:errs.append([rec['key'],'source'])
 n+=1
result={'successful_composites_checked':n,'expected_missing_bom_rejections':4,'errors':errs,'status':'PASS' if not errs else 'FAIL'}
(V/'tests_out/independent_boms.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(result);assert not errs
