Attribute VB_Name = "modTest"
Option Explicit
' Полная повторяемая матрица в ОТДЕЛЬНОЙ пустой книге. Рабочий журнал не очищается.
Public Sub ELKA_SelfTest()
    Dim report As String
    If Not Ask("Тест заполнит ПУСТУЮ книгу учебными движениями. Это отдельная тестовая копия?") Then Exit Sub
    report = RunSelfTest("")
    SaveTestReport report
    Info report
End Sub
Public Function RunSelfTest(ByVal sampleFolder As String) As String
    Dim seq As Variant, entry As Variant, ops As Variant, item As Variant
    Dim i As Long, v As String, rep As String, passed As Long, failed As Long
    Dim sh As Worksheet, r As Long, code As String, seen As Collection, hasBOM As Boolean
    Dim oldSilent As Boolean
    oldSilent = gSilent: gSilent = True
    On Error GoTo Bad
    If LastRow(WS(SH_MOVE), J_OP) >= FIRST_ROW Then
        RunSelfTest = "ОТКАЗ: журнал не пуст. Создайте отдельную копию пустого шаблона. Рабочие данные не удалены."
        GoTo Done
    End If
    seq = Split("01,10000;02,100;03,1;04,98;05,3000;06,2000;07,1;08,1;09,1;10,1;11,1;12,1;13,1;14,1;15,1;16,1;17,5;18,1;19,5;20,1;21,5;22,1;23,1;24,1;25,1;26,1;27,2;28,3;29,1;30,1;31,1;32,1;33,1;34,1;35,1;36,1;40,1;41,1;42,1;43,1;44,1;45,40;46,20;47,1", ";")
    For i = LBound(seq) To UBound(seq)
        entry = Split(seq(i), ",")
        item = ""
        Select Case CStr(entry(0))
        Case "27", "41": item = "ПФД-01"
        Case "28": item = "ГП-01"
        Case "34": item = "ЦС-A-01-02"
        Case "35": item = "ПС-02-01"
        Case "36": item = "ГП-02"
        Case "44": item = "ПФД-02"
        Case "45", "47": item = "РЕМ-01"
        Case "46": item = "ПР-УЧ1"
        End Select
        v = Acceptance_Batch(CStr(entry(0)), CDbl(entry(1)), False, CStr(item))
        AddResult "Операция " & entry(0), v, Left$(v, 5) = "PASS|", passed, failed, rep
        If Left$(v, 5) <> "PASS|" Then GoTo Finish
        v = Acceptance_Batch(CStr(entry(0)), CDbl(entry(1)), True, CStr(item))
        AddResult "Отклонение типов " & entry(0), v, Left$(v, 10) = "REJECT_OK|" Or v = "EMPTY", passed, failed, rep
    Next i
    ops = Split("negative_qty;zero_qty;no_order;unknown_order;wrong_addr;unknown_code;overdraw;duplicate_overdraw;array_size;inactive", ";")
    For Each item In ops
        v = Acceptance_Negative(CStr(item))
        AddResult CStr(item), v, Left$(v, 5) = "PASS|", passed, failed, rep
    Next item
    Set seen = New Collection: Set sh = WS(SH_SPEC)
    For r = FIRST_ROW To LastRow(sh, 1)
        code = Txt(sh.Cells(r, 1).Value)
        If Len(code) > 0 And KeyIndex(seen, code) = 0 Then
            KeyAdd seen, code, r
            v = Acceptance_Complex("assemble", code)
            AddResult "Сборка " & code, v, Left$(v, 5) = "PASS|", passed, failed, rep
        End If
    Next r
    Set seen = New Collection: Set sh = WS(SH_PFD)
    For r = FIRST_ROW To LastRow(sh, 1)
        code = Txt(sh.Cells(r, 1).Value)
        If Len(code) > 0 And KeyIndex(seen, code) = 0 Then
            KeyAdd seen, code, r
            v = Acceptance_Complex("assemble", code)
            AddResult "ПФД " & code, v, Left$(v, 5) = "PASS|", passed, failed, rep
            v = Acceptance_Complex("complete", code)
            AddResult "Доукомплектация " & code, v, Left$(v, 5) = "PASS|", passed, failed, rep
        End If
    Next r
    Set sh = WS(SH_NOM)
    For r = FIRST_ROW To LastRow(sh, 1)
        If Txt(sh.Cells(r, N_TYPE).Value) = T_BUNDLE Then
            code = Txt(sh.Cells(r, 1).Value)
            hasBOM = FindRow(WS(SH_BUNDLE), 1, code) > 0
            For Each item In Array("build", "split")
                v = Acceptance_Complex(CStr(item), code)
                AddResult CStr(item) & " " & code, v, (hasBOM And Left$(v, 5) = "PASS|") Or (Not hasBOM And Left$(v, 7) = "REJECT|"), passed, failed, rep
            Next item
        End If
    Next r
Finish:
    v = Acceptance_Reports()
    AddResult "Контроль", v, v = "REFRESH|0", passed, failed, rep
    RunSelfTest = "ELKA v" & ELKA_VERSION & vbLf & "Пройдено сценариев: " & passed & "; ошибок: " & failed & vbLf & "Матрица: 255 позиций x 44 операции (если справочники исходные)." & vbLf & "Нет состава двух объединений: ожидаемый отказ, не подтверждение их сборки." & vbLf & rep
    GoTo Done
Bad:
    RunSelfTest = "ТЕСТ ПРЕРВАН: " & Err.Description & vbLf & rep
Done:
    IndexEnd
    AppOn
    gSilent = oldSilent
End Function
Private Sub AddResult(ByVal title As String, ByVal detail As String, ByVal ok As Boolean, ByRef passed As Long, ByRef failed As Long, ByRef rep As String)
    If ok Then passed = passed + 1 Else failed = failed + 1
    rep = rep & IIf(ok, "PASS ", "FAIL ") & title & ": " & detail & vbLf
End Sub

Private Sub SaveTestReport(ByVal report As String)
    Dim sh As Worksheet, lines As Variant, i As Long
    On Error Resume Next
    Set sh = ThisWorkbook.Worksheets("Тест_отчёт")
    On Error GoTo 0
    If sh Is Nothing Then
        Set sh = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        sh.Name = "Тест_отчёт"
    End If
    sh.Cells.Clear
    sh.Range("A1").Value = "Приёмочный тест ELKA — только отдельная тестовая книга"
    sh.Range("A1").Font.Bold = True
    sh.Columns(1).ColumnWidth = 130
    lines = Split(report, vbLf)
    For i = LBound(lines) To UBound(lines)
        sh.Cells(i + 3, 1).Value = lines(i)
    Next i
    sh.Activate
End Sub
