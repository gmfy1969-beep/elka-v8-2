Attribute VB_Name = "modIntegrity"
Option Explicit
' Проверка бизнес-справочников, которые использует автоматика.
Public Function ValidPFD(ByVal code As String, ByRef reason As String) As Boolean
    Dim target As String, c() As String, q() As Double, n As Long
    Dim m() As String, mq() As Double, k As Long, i As Long, j As Long, total As Double, norm As Double
    target = PFDTarget(code)
    If NomType(code) <> T_PFD Or (NomType(target) <> T_PF And NomType(target) <> T_GP) Then reason = "Неверный код/тип ПФД или целевого изделия.": Exit Function
    n = GetComposition(SH_SPEC, target, c, q)
    k = PFDMissing(code, m, mq)
    If n = 0 Or k = 0 Then reason = "Нет спецификации или перечня дефицита.": Exit Function
    For i = 1 To k
        total = 0: norm = 0
        For j = 1 To k
            If StrComp(m(j), m(i), vbTextCompare) = 0 Then total = total + mq(j)
        Next j
        For j = 1 To n
            If StrComp(c(j), m(i), vbTextCompare) = 0 Then norm = norm + q(j)
        Next j
        If NomRow(m(i)) = 0 Or mq(i) <= 0 Or total > norm + 0.0000001 Or norm <= 0 Then
            reason = "Некорректный дефицит " & m(i) & ": количество должно быть >0 и не выше нормы спецификации.": Exit Function
        End If
    Next i
    ValidPFD = True
End Function
Public Function ReferenceErrors() As String
    Dim sh As Worksheet, r As Long, code As String, e As String, reason As String
    Dim seen As New Collection
    Set sh = WS(SH_PFD)
    For r = FIRST_ROW To LastRow(sh, 1)
        code = Txt(sh.Cells(r, 1).Value)
        If Len(code) > 0 And KeyIndex(seen, code) = 0 Then
            KeyAdd seen, code, r
            If Not ValidPFD(code, reason) Then e = e & "ПФД " & code & ": " & reason & vbLf
        End If
    Next r
    Set seen = New Collection: Set sh = WS(SH_ORDERS)
    For r = FIRST_ROW To LastRow(sh, 1)
        code = Txt(sh.Cells(r, 1).Value)
        If Len(code) > 0 Then
            If KeyIndex(seen, code) > 0 Then e = e & "Дублируется заказ " & code & vbLf
            KeyAdd seen, code, r
            If NomRow(Txt(sh.Cells(r, O_ITEM).Value)) = 0 Then e = e & "Заказ " & code & ": нет изделия в справочнике" & vbLf
            If Nz(sh.Cells(r, O_PLAN).Value) < 0 Then e = e & "Заказ " & code & ": отрицательный план" & vbLf
        End If
    Next r
    Set seen = New Collection: Set sh = WS(SH_LOC)
    For r = FIRST_ROW To LastRow(sh, 1)
        code = Txt(sh.Cells(r, 1).Value)
        If Len(code) > 0 Then
            If KeyIndex(seen, code) > 0 Then e = e & "Дублируется место " & code & vbLf
            KeyAdd seen, code, r
        End If
    Next r
    ReferenceErrors = e
End Function
Public Function MissingBundleBOMs() As String
    Dim sh As Worksheet, r As Long, code As String
    Set sh = WS(SH_NOM)
    For r = FIRST_ROW To LastRow(sh, 1)
        If Txt(sh.Cells(r, N_TYPE).Value) = T_BUNDLE Then
            code = Txt(sh.Cells(r, N_CODE).Value)
            If FindRow(WS(SH_BUNDLE), 1, code) = 0 Then MissingBundleBOMs = MissingBundleBOMs & code & vbLf
        End If
    Next r
End Function
