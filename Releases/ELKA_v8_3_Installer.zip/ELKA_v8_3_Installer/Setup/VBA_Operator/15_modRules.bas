Attribute VB_Name = "modRules"
Option Explicit
' Ограничения выпуска/отгрузки и специализированных операций по типу позиции.
' Остальные перемещения допустимы для любой активной учитываемой позиции.
Public Function OperationAllowsType(ByVal opCode As String, ByVal typ As String) As Boolean
    If typ = T_VARPARENT Then Exit Function
    Select Case opCode
    Case "08": OperationAllowsType = (typ = T_PF)
    Case "09", "10", "28", "36": OperationAllowsType = (typ = T_GP)
    Case "27", "41", "42", "44": OperationAllowsType = (typ = T_PFD)
    Case "30", "33": OperationAllowsType = (typ = T_BUNDLE)
    Case Else: OperationAllowsType = True
    End Select
End Function
