Attribute VB_Name = "modIndex"
Option Explicit
' v8.3: кэш справочников только на время одной операции/проверки.
' При каждом новом документе перечитывается: ручные правки не теряются.
Public gIndexActive As Boolean
Private mNom As Variant, mAddr As Variant, mOps As Variant, mSet As Variant
Private mLoc As Variant, mOrders As Variant
Private mNomKeys As Collection, mAddrKeys As Collection, mOpKeys As Collection
Private mLocKeys As Collection, mSetKeys As Collection, mOrderKeys As Collection
Private Function ReadBlock(ByVal nm As String, ByVal cols As Long) As Variant
    Dim sh As Worksheet, lastR As Long
    Set sh = WS(nm): lastR = LastRow(sh, 1)
    If lastR < FIRST_ROW Then lastR = FIRST_ROW
    ReadBlock = sh.Range(sh.Cells(FIRST_ROW, 1), sh.Cells(lastR, cols)).Value
End Function
Private Function MakeIndex(a As Variant, ByVal col As Long) As Collection
    Dim k As New Collection, i As Long, t As String
    For i = 1 To UBound(a, 1)
        t = Txt(a(i, col))
        If Len(t) > 0 Then KeyAdd k, t, i
    Next i
    Set MakeIndex = k
End Function
Public Sub IndexBegin()
    gIndexActive = False
    mNom = ReadBlock(SH_NOM, N_LAST): Set mNomKeys = MakeIndex(mNom, 1)
    mAddr = ReadBlock(SH_ADDR, 9): Set mAddrKeys = MakeIndex(mAddr, 1)
    mOps = ReadBlock(SH_OPS, 10): Set mOpKeys = MakeIndex(mOps, 2)
    mSet = ReadBlock(SH_SET, 3): Set mSetKeys = MakeIndex(mSet, 1)
    mLoc = ReadBlock(SH_LOC, 8): Set mLocKeys = MakeIndex(mLoc, 1)
    mOrders = ReadBlock(SH_ORDERS, 11): Set mOrderKeys = MakeIndex(mOrders, 1)
    gIndexActive = True
End Sub
Public Sub IndexEnd()
    gIndexActive = False
End Sub
Public Function IndexSetting(ByVal nm As String, ByVal fallback As String) As String
    Dim i As Long
    i = KeyIndex(mSetKeys, nm): IndexSetting = fallback
    If i > 0 Then
        If Len(Txt(mSet(i, 2))) > 0 Then IndexSetting = Txt(mSet(i, 2))
    End If
End Function
Public Function IndexNomRow(ByVal code As String) As Long
    Dim i As Long
    i = KeyIndex(mNomKeys, code)
    If i > 0 Then IndexNomRow = FIRST_ROW + i - 1
End Function
Public Function IndexNomValue(ByVal code As String, ByVal col As Long) As Variant
    Dim i As Long
    i = KeyIndex(mNomKeys, code)
    If i > 0 Then IndexNomValue = mNom(i, col)
End Function
Public Function IndexAddrOk(ByVal a As String, ByVal loc As String) As Boolean
    Dim i As Long
    i = KeyIndex(mAddrKeys, a)
    If i = 0 Then Exit Function
    If StrComp(Txt(mAddr(i, 2)), loc, vbTextCompare) <> 0 Then Exit Function
    IndexAddrOk = (Len(Txt(mAddr(i, 8))) = 0 Or IsYes(mAddr(i, 8)))
End Function
Public Function IndexDefaultAddr(ByVal code As String, ByVal loc As String) As String
    Dim a As String, i As Long, n As Long
    a = Txt(IndexNomValue(code, N_DEFADDR))
    If IndexAddrOk(a, loc) Then IndexDefaultAddr = a: Exit Function
    For i = 1 To UBound(mAddr, 1)
        If StrComp(Txt(mAddr(i, 2)), loc, vbTextCompare) = 0 And (Len(Txt(mAddr(i, 8))) = 0 Or IsYes(mAddr(i, 8))) Then
            n = n + 1: a = Txt(mAddr(i, 1))
        End If
    Next i
    If n = 1 Then IndexDefaultAddr = a
End Function
Public Function IndexPickAddr(ByVal code As String, ByVal loc As String, ByVal qty As Double) As String
    Dim a As String, i As Long
    If BalGet("A|" & UCase$(code) & "|" & UCase$(loc) & "|") >= qty - 0.0000001 Then Exit Function
    a = IndexDefaultAddr(code, loc)
    If Len(a) > 0 Then
        If BalGet("A|" & UCase$(code) & "|" & UCase$(loc) & "|" & UCase$(a)) >= qty - 0.0000001 Then IndexPickAddr = a: Exit Function
    End If
    For i = 1 To UBound(mAddr, 1)
        a = Txt(mAddr(i, 1))
        If IndexAddrOk(a, loc) Then
            If BalGet("A|" & UCase$(code) & "|" & UCase$(loc) & "|" & UCase$(a)) >= qty - 0.0000001 Then IndexPickAddr = a: Exit Function
        End If
    Next i
End Function
Public Function IndexOpName(ByVal text As String) As String
    Dim i As Long, code As String
    If IsNumeric(text) And Len(text) = 1 Then text = "0" & text
    i = KeyIndex(mOpKeys, text)
    If i > 0 Then IndexOpName = Txt(mOps(i, 2)): Exit Function
    For i = 1 To UBound(mOps, 1)
        code = Txt(mOps(i, 1))
        If StrComp(code, text, vbTextCompare) = 0 Then IndexOpName = Txt(mOps(i, 2)): Exit Function
    Next i
End Function
Public Function IndexTracked(ByVal loc As String) As Boolean
    Dim i As Long
    i = KeyIndex(mLocKeys, loc)
    If i > 0 Then IndexTracked = IsYes(mLoc(i, 4))
End Function
Public Function IndexOrderExists(ByVal nm As String) As Boolean
    IndexOrderExists = (KeyIndex(mOrderKeys, nm) > 0)
End Function
Public Function IndexFind(ByVal nm As String, ByVal col As Long, ByVal text As String, ByRef supported As Boolean) As Long
    Dim a As Variant, i As Long
    supported = True
    Select Case nm
    Case SH_NOM: a = mNom
    Case SH_ADDR: a = mAddr
    Case SH_OPS: a = mOps
    Case SH_LOC: a = mLoc
    Case SH_SET: a = mSet
    Case SH_ORDERS: a = mOrders
    Case Else: supported = False: Exit Function
    End Select
    If col > UBound(a, 2) Then supported = False: Exit Function
    For i = 1 To UBound(a, 1)
        If StrComp(Txt(a(i, col)), text, vbTextCompare) = 0 Then IndexFind = FIRST_ROW + i - 1: Exit Function
    Next i
End Function
