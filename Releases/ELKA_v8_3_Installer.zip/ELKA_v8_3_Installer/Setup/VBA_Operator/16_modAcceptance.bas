Attribute VB_Name = "modAcceptance"
Option Explicit
' Исполнение матрицы 255 x все операции: штатный PostDoc, без обхода проверок.
' Использовать только в отдельной пустой тестовой книге.
Public Function Acceptance_Batch(ByVal op As String, ByVal qty As Double, ByVal rejectGroup As Boolean, Optional ByVal addrTo As String = "") As String
    Dim sh As Worksheet, a As Variant, r As Long, n As Long, code As String, typ As String
    Dim codes() As String, qs() As Double, af() As String, at() As String
    Dim d As String, before As Long, expected As Boolean, msg As String
    gSilent = True
    Set sh = WS(SH_NOM)
    a = sh.Range(sh.Cells(FIRST_ROW, 1), sh.Cells(LastRow(sh, 1), N_LAST)).Value
    ReDim codes(1 To UBound(a, 1)): ReDim qs(1 To UBound(a, 1))
    ReDim af(1 To UBound(a, 1)): ReDim at(1 To UBound(a, 1))
    For r = 1 To UBound(a, 1)
        code = Txt(a(r, N_CODE)): typ = Txt(a(r, N_TYPE))
        expected = OperationAllowsType(op, typ) And IsYes(a(r, N_ACTIVE))
        If Len(code) > 0 And expected <> rejectGroup Then
            n = n + 1: codes(n) = code: qs(n) = qty: at(n) = addrTo
        End If
    Next r
    If n = 0 Then Acceptance_Batch = "EMPTY": Exit Function
    ReDim Preserve codes(1 To n): ReDim Preserve qs(1 To n)
    ReDim Preserve af(1 To n): ReDim Preserve at(1 To n)
    before = LastRow(WS(SH_MOVE), J_OP)
    AppOff
    d = PostDoc(op, DateSerial(2026, 10, 1), Txt(WS(SH_ORDERS).Cells(FIRST_ROW, 1).Value), Txt(WS(SH_ORDERS).Cells(FIRST_ROW, 3).Value), "ACCEPTANCE", "Приёмочный тест " & op, codes, qs, af, at)
    AppOn
    msg = gLastError
    If rejectGroup Then
        If Len(d) > 0 Or LastRow(WS(SH_MOVE), J_OP) <> before Then Acceptance_Batch = "FAIL rejected-group persisted": Exit Function
        For r = 1 To n
            If InStr(1, msg, codes(r), vbTextCompare) = 0 Then Acceptance_Batch = "FAIL no rejection reason for " & codes(r): Exit Function
        Next r
        Acceptance_Batch = "REJECT_OK|" & n
    Else
        If Len(d) = 0 Or LastRow(WS(SH_MOVE), J_OP) <> before + n Then Acceptance_Batch = "FAIL " & msg: Exit Function
        Acceptance_Batch = "PASS|" & n & "|" & d
    End If
End Function
Public Function Acceptance_Complex(ByVal mode As String, ByVal code As String) As String
    Dim d As String, order As String
    gSilent = True
    order = Txt(WS(SH_ORDERS).Cells(FIRST_ROW, 1).Value)
    AppOff
    Select Case mode
    Case "assemble": d = AssembleCore(code, 1, order, DateSerial(2026, 10, 1))
    Case "complete": d = PFDCompleteCore(code, 1, order, DateSerial(2026, 10, 1))
    Case "build": d = BundleBuildCore(code, 1, DateSerial(2026, 10, 1))
    Case "split": d = BundleSplitCore(code, 1, DateSerial(2026, 10, 1))
    End Select
    AppOn
    If Len(d) = 0 Then Acceptance_Complex = "REJECT|" & gLastError Else Acceptance_Complex = "PASS|" & d
End Function
Public Function Acceptance_Negative(ByVal scenario As String) As String
    Dim code As String, order As String, item As String, d As String, op As String, n As Long
    Dim codes As Variant, qs As Variant, af As Variant, at As Variant
    gSilent = True
    code = Txt(WS(SH_NOM).Cells(FIRST_ROW, 1).Value)
    order = Txt(WS(SH_ORDERS).Cells(FIRST_ROW, 1).Value)
    item = Txt(WS(SH_ORDERS).Cells(FIRST_ROW, 3).Value)
    codes = Array(code): qs = Array(1): af = Array(""): at = Array(""): op = "45"
    Select Case scenario
    Case "negative_qty": qs = Array(-1)
    Case "zero_qty": qs = Array(0)
    Case "no_order": order = ""
    Case "unknown_order": order = "NO-SUCH-ORDER"
    Case "wrong_addr": at = Array("ЦС-A-01-01")
    Case "unknown_code": codes = Array("NO-SUCH-CODE")
    Case "overdraw": op = "46": qs = Array(99999999)
    Case "duplicate_overdraw": op = "46": codes = Array(code, code): qs = Array(15, 15): af = Array("РЕМ-01", "РЕМ-01"): at = Array("", "")
    Case "array_size": codes = Array(code, code)
    Case "inactive"
        WS(SH_NOM).Cells(FIRST_ROW, N_ACTIVE).Value = "Нет"
    End Select
    n = LastRow(WS(SH_MOVE), J_OP)
    d = PostDoc(op, DateSerial(2026, 10, 1), order, item, "", scenario, codes, qs, af, at)
    If scenario = "inactive" Then WS(SH_NOM).Cells(FIRST_ROW, N_ACTIVE).Value = "Да"
    If Len(d) = 0 And LastRow(WS(SH_MOVE), J_OP) = n Then Acceptance_Negative = "PASS|" & gLastError Else Acceptance_Negative = "FAIL|document persisted"
End Function
Public Function Acceptance_Reports() As String
    gSilent = True
    Reports_RefreshAll
    Acceptance_Reports = "REFRESH|" & ControlErrors()
End Function
